from flask import Flask, request, render_template
import numpy as np
import pickle

app = Flask(__name__)

model = pickle.load(open("model.pkl", "rb"))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    features = [float(x) for x in request.form.values()]
    final_features = [np.array(features)]
    prediction = model.predict(final_features)

    if prediction[0] == 1:
        output = "Person has Heart Disease"
    else:
        output = "Person does NOT have Heart Disease"

    return render_template("index.html", prediction_text=output)

if __name__ == "__main__":
    app.run(debug=True)